export interface Process {
  id: string;
  name: string;
  arrivalTime: number;
  burstTime: number;
  remainingTime: number;
  priority: number;
  state: ProcessState;
  memorySize: number;
  memoryAddress?: number;
  pageTableEntries: PageTableEntry[];
  pcb: PCB;
  createdAt: number;
  startTime?: number;
  endTime?: number;
  waitingTime: number;
  turnaroundTime: number;
  ioOperations: IOOperation[];
  currentIOOperation?: IOOperation;
  systemCalls: SystemCall[];
  currentSystemCall?: SystemCall;
}

export interface PCB {
  processId: string;
  programCounter: number;
  registers: { [key: string]: number };
  memoryLimits: { base: number; limit: number };
  fileHandles: string[];
  cpuTime: number;
  priority: number;
}

export interface PageTableEntry {
  pageNumber: number;
  frameNumber: number;
  valid: boolean;
  dirty: boolean;
  referenced: boolean;
  lastAccessTime?: number;
  processId?: string;
  processName?: string;
}

export interface MemoryBlock {
  id: string;
  startAddress: number;
  size: number;
  allocated: boolean;
  processId?: string;
  processName?: string;
}

export interface Interrupt {
  id: string;
  type: InterruptType;
  processId?: string;
  timestamp: number;
  handled: boolean;
  priority: number;
  description?: string;
}

export interface IOOperation {
  id: string;
  type: IOType;
  duration: number;
  remainingTime: number;
  startTime: number;
}

export interface SystemCall {
  id: string;
  type: SystemCallType;
  duration: number;
  remainingTime: number;
  startTime: number;
}

export interface PageFrame {
  frameNumber: number;
  pageNumber?: number;
  processId?: string;
  processName?: string;
  allocated: boolean;
  referenceBit: boolean;
  modifyBit: boolean;
  lastAccessTime: number;
  loadTime: number;
  secondChance: boolean;
}

export interface RoundRobinConfig {
  isPreemptive: boolean;
  orderBy: 'arrival' | 'priority';
}

export enum ProcessState {
  NEW = 'Nuevo',
  READY = 'Listo',
  RUNNING = 'Ejecutando',
  BLOCKED = 'Bloqueado',
  TERMINATED = 'Terminado'
}

export enum SchedulingAlgorithm {
  FCFS = 'First Come First Served',
  SJF = 'Shortest Job First',
  RR = 'Round Robin',
  PRIORITY = 'Priority Scheduling'
}

export enum MemoryAllocationAlgorithm {
  FIRST_FIT = 'First Fit',
  BEST_FIT = 'Best Fit',
  WORST_FIT = 'Worst Fit'
}

export enum PageReplacementAlgorithm {
  FIFO = 'FIFO (First In First Out)',
  SECOND_CHANCE = 'Second Chance',
  NRU = 'NRU (Not Recently Used)',
  LRU = 'LRU (Least Recently Used)'
}

export enum InterruptType {
  TIMER = 'Temporizador',
  IO = 'E/S',
  KEYBOARD = 'Teclado',
  MOUSE = 'Ratón',
  DISK = 'Disco',
  NETWORK = 'Red',
  PAGE_FAULT = 'Fallo de Página',
  SYSTEM_CALL = 'Llamada al Sistema'
}

export enum IOType {
  DISK_READ = 'Lectura de Disco',
  DISK_WRITE = 'Escritura de Disco',
  NETWORK_REQUEST = 'Petición de Red',
  KEYBOARD_INPUT = 'Entrada de Teclado',
  MOUSE_INPUT = 'Entrada de Ratón',
  PRINTER = 'Impresora',
  FILE_OPERATION = 'Operación de Archivo'
}

export enum SystemCallType {
  FILE_OPEN = 'Abrir Archivo',
  FILE_READ = 'Leer Archivo',
  FILE_WRITE = 'Escribir Archivo',
  FILE_CLOSE = 'Cerrar Archivo',
  MEMORY_ALLOC = 'Asignar Memoria',
  MEMORY_FREE = 'Liberar Memoria',
  PROCESS_CREATE = 'Crear Proceso',
  PROCESS_KILL = 'Terminar Proceso',
  NETWORK_SEND = 'Enviar Red',
  NETWORK_RECEIVE = 'Recibir Red'
}

export interface SystemStats {
  totalProcesses: number;
  runningProcesses: number;
  readyProcesses: number;
  blockedProcesses: number;
  terminatedProcesses: number;
  memoryUtilization: number;
  cpuUtilization: number;
  contextSwitches: number;
  interruptCount: number;
  averageWaitTime: number;
  averageTurnaroundTime: number;
}