import React, { useState } from 'react';
import { Play, Pause, RotateCcw, Plus, Settings, HardDrive, Zap } from 'lucide-react';
import { Process, ProcessState, SchedulingAlgorithm, RoundRobinConfig } from '../types';
import { PROCESS_STATE_COLORS, SAMPLE_PROCESSES, IO_TYPE_COLORS, SYSTEM_CALL_COLORS } from '../utils/constants';
import { ProcessForm } from './ProcessForm';

interface ProcessSchedulerProps {
  processes: Process[];
  currentProcess: Process | null;
  algorithm: SchedulingAlgorithm;
  timeQuantum: number;
  isRunning: boolean;
  currentTime: number;
  quantumRemaining: number;
  roundRobinConfig: RoundRobinConfig;
  onAlgorithmChange: (algorithm: SchedulingAlgorithm) => void;
  onTimeQuantumChange: (quantum: number) => void;
  onRoundRobinConfigChange: (config: Partial<RoundRobinConfig>) => void;
  onStart: () => void;
  onStop: () => void;
  onReset: () => void;
  onAddProcess: (name: string, burstTime: number, priority: number, memorySize: number) => void;
}

export const ProcessScheduler: React.FC<ProcessSchedulerProps> = ({
  processes,
  currentProcess,
  algorithm,
  timeQuantum,
  isRunning,
  currentTime,
  quantumRemaining,
  roundRobinConfig,
  onAlgorithmChange,
  onTimeQuantumChange,
  onRoundRobinConfigChange,
  onStart,
  onStop,
  onReset,
  onAddProcess
}) => {
  const [showProcessForm, setShowProcessForm] = useState(false);

  const handleAddSampleProcess = () => {
    // Get existing process names to avoid duplicates
    const existingNames = processes.map(p => p.name.split(' #')[0]);
    
    // Find available sample processes
    const availableProcesses = SAMPLE_PROCESSES.filter(sample => 
      !existingNames.includes(sample.name)
    );
    
    if (availableProcesses.length === 0) {
      // If all sample processes exist, create a variation
      const sample = SAMPLE_PROCESSES[Math.floor(Math.random() * SAMPLE_PROCESSES.length)];
      const processCount = processes.filter(p => p.name.startsWith(sample.name)).length;
      onAddProcess(
        `${sample.name} #${processCount + 1}`,
        sample.burstTime + Math.floor(Math.random() * 3) - 1, // Slight variation
        sample.priority,
        sample.memorySize
      );
    } else {
      // Add a random available process
      const sample = availableProcesses[Math.floor(Math.random() * availableProcesses.length)];
      onAddProcess(
        sample.name,
        sample.burstTime,
        sample.priority,
        sample.memorySize
      );
    }
  };

  const handleCreateCustomProcess = (name: string, burstTime: number, priority: number, memorySize: number) => {
    onAddProcess(name, burstTime, priority, memorySize);
  };

  const getProcessCounts = () => {
    const counts = processes.reduce((acc, process) => {
      acc[process.state] = (acc[process.state] || 0) + 1;
      return acc;
    }, {} as Record<ProcessState, number>);
    
    return Object.values(ProcessState).map(state => ({
      state,
      count: counts[state] || 0,
      color: PROCESS_STATE_COLORS[state]
    }));
  };

  const getTotalMemoryUsed = () => {
    return processes
      .filter(p => p.state !== ProcessState.TERMINATED)
      .reduce((total, p) => total + p.memorySize, 0);
  };

  const getMemoryUtilization = () => {
    return (getTotalMemoryUsed() / 65536) * 100;
  };

  const getBlockedProcesses = () => {
    return processes.filter(p => p.state === ProcessState.BLOCKED);
  };

  const getReadyProcesses = () => {
    const readyProcesses = processes.filter(p => p.state === ProcessState.READY);
    
    if (algorithm === SchedulingAlgorithm.RR && roundRobinConfig.orderBy === 'priority') {
      return readyProcesses.sort((a, b) => {
        if (a.priority !== b.priority) {
          return a.priority - b.priority;
        }
        return a.arrivalTime - b.arrivalTime;
      });
    } else {
      return readyProcesses.sort((a, b) => a.arrivalTime - b.arrivalTime);
    }
  };

  return (
    <>
      <div className="bg-gray-800 rounded-lg p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Planificador de Procesos</h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={isRunning ? onStop : onStart}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isRunning 
                  ? 'bg-red-600 hover:bg-red-700 text-white' 
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {isRunning ? <Pause size={16} /> : <Play size={16} />}
              <span>{isRunning ? 'Pausar' : 'Iniciar'}</span>
            </button>
            <button
              onClick={onReset}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
            >
              <RotateCcw size={16} />
              <span>Reiniciar</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">
              Algoritmo de Planificación
            </label>
            <select
              value={algorithm}
              onChange={(e) => onAlgorithmChange(e.target.value as SchedulingAlgorithm)}
              className="w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {Object.values(SchedulingAlgorithm).map(alg => (
                <option key={alg} value={alg}>{alg}</option>
              ))}
            </select>
          </div>

          {algorithm === SchedulingAlgorithm.RR && (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-300">
                Quantum de Tiempo
              </label>
              <input
                type="number"
                value={timeQuantum}
                onChange={(e) => onTimeQuantumChange(Number(e.target.value))}
                min="1"
                max="20"
                className="w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">
              Tiempo del Sistema
            </label>
            <div className="bg-gray-700 text-white rounded-lg px-3 py-2 font-mono">
              {currentTime}
            </div>
          </div>

          {algorithm === SchedulingAlgorithm.RR && (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-300">
                Quantum Restante
              </label>
              <div className="bg-gray-700 text-white rounded-lg px-3 py-2 font-mono">
                {quantumRemaining}
              </div>
            </div>
          )}
        </div>

        {/* Round Robin Configuration */}
        {algorithm === SchedulingAlgorithm.RR && (
          <div className="bg-gray-700 rounded-lg p-4 space-y-4">
            <h3 className="text-lg font-semibold text-white">Configuración Round Robin</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Tipo de Planificación
                </label>
                <select
                  value={roundRobinConfig.isPreemptive ? 'preemptive' : 'non-preemptive'}
                  onChange={(e) => onRoundRobinConfigChange({ 
                    isPreemptive: e.target.value === 'preemptive' 
                  })}
                  className="w-full bg-gray-600 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="preemptive">Expropiativo (Preemptive)</option>
                  <option value="non-preemptive">No Expropiativo (Non-preemptive)</option>
                </select>
                <p className="text-xs text-gray-400">
                  {roundRobinConfig.isPreemptive 
                    ? 'Los procesos de mayor prioridad pueden interrumpir al proceso actual'
                    : 'Los procesos ejecutan sin ser interrumpidos por otros de mayor prioridad'
                  }
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Orden de Selección
                </label>
                <select
                  value={roundRobinConfig.orderBy}
                  onChange={(e) => onRoundRobinConfigChange({ 
                    orderBy: e.target.value as 'arrival' | 'priority' 
                  })}
                  className="w-full bg-gray-600 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="arrival">Por Orden de Llegada</option>
                  <option value="priority">Por Prioridad</option>
                </select>
                <p className="text-xs text-gray-400">
                  {roundRobinConfig.orderBy === 'arrival'
                    ? 'Los procesos se seleccionan por orden de llegada'
                    : 'Los procesos se seleccionan por prioridad (menor número = mayor prioridad)'
                  }
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Memory usage warning */}
        {getMemoryUtilization() > 80 && (
          <div className="bg-yellow-900 border border-yellow-600 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <span className="text-yellow-200 text-sm">
                Advertencia: Uso de memoria alto ({getMemoryUtilization().toFixed(1)}%). 
                Considera terminar algunos procesos.
              </span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {getProcessCounts().map(({ state, count, color }) => (
            <div key={state} className="text-center">
              <div className="text-2xl font-bold text-white">{count}</div>
              <div className="text-sm" style={{ color }}>
                {state}
              </div>
            </div>
          ))}
        </div>

        {currentProcess && (
          <div className="bg-gray-700 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-3">Ejecutándose Actualmente</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Proceso:</span>
                <div className="text-white font-medium">{currentProcess.name}</div>
              </div>
              <div>
                <span className="text-gray-400">Tiempo Restante:</span>
                <div className="text-white font-medium">{currentProcess.remainingTime}</div>
              </div>
              <div>
                <span className="text-gray-400">Prioridad:</span>
                <div className="text-white font-medium">{currentProcess.priority}</div>
              </div>
              {algorithm === SchedulingAlgorithm.RR && (
                <div>
                  <span className="text-gray-400">Quantum Restante:</span>
                  <div className="text-white font-medium">{quantumRemaining}</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Blocked processes section */}
        {getBlockedProcesses().length > 0 && (
          <div className="bg-gray-700 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center space-x-2">
              <HardDrive size={20} />
              <span>Procesos Bloqueados</span>
            </h3>
            <div className="space-y-2">
              {getBlockedProcesses().map((process) => (
                <div key={process.id} className="bg-gray-600 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: PROCESS_STATE_COLORS[process.state] }}
                      />
                      <span className="text-white font-medium">{process.name}</span>
                    </div>
                    <div className="text-right">
                      {process.currentIOOperation && (
                        <div className="flex items-center space-x-2">
                          <HardDrive size={16} className="text-blue-400" />
                          <div>
                            <div className="text-white text-sm font-medium">
                              {process.currentIOOperation.type}
                            </div>
                            <div className="text-gray-400 text-xs">
                              Restante: {process.currentIOOperation.remainingTime}s
                            </div>
                          </div>
                        </div>
                      )}
                      {process.currentSystemCall && (
                        <div className="flex items-center space-x-2">
                          <Zap size={16} className="text-purple-400" />
                          <div>
                            <div className="text-white text-sm font-medium">
                              {process.currentSystemCall.type}
                            </div>
                            <div className="text-gray-400 text-xs">
                              Restante: {process.currentSystemCall.remainingTime}s
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">
            Cola de Procesos
            {algorithm === SchedulingAlgorithm.RR && (
              <span className="text-sm text-gray-400 ml-2">
                (Ordenados por {roundRobinConfig.orderBy === 'arrival' ? 'llegada' : 'prioridad'})
              </span>
            )}
          </h3>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowProcessForm(true)}
              className="flex items-center space-x-2 px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition-colors"
            >
              <Settings size={14} />
              <span>Crear Personalizado</span>
            </button>
            <button
              onClick={handleAddSampleProcess}
              disabled={getMemoryUtilization() > 90}
              className={`flex items-center space-x-2 px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                getMemoryUtilization() > 90
                  ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              <Plus size={14} />
              <span>Agregar Muestra</span>
            </button>
          </div>
        </div>

        <div className="space-y-2 max-h-64 overflow-y-auto">
          {processes.length === 0 ? (
            <div className="text-gray-400 text-center py-8">
              <p className="mb-2">No hay procesos en el sistema</p>
              <p className="text-sm">Agrega un proceso para comenzar la simulación</p>
            </div>
          ) : (
            <>
              {/* Show ready processes in order */}
              {getReadyProcesses().length > 0 && (
                <div className="mb-4">
                  <h4 className="text-md font-medium text-white mb-2">
                    Procesos Listos {algorithm === SchedulingAlgorithm.RR && `(${roundRobinConfig.orderBy === 'arrival' ? 'Por llegada' : 'Por prioridad'})`}
                  </h4>
                  {getReadyProcesses().map((process, index) => (
                    <div
                      key={process.id}
                      className={`bg-gray-700 rounded-lg p-3 border-l-4 border-blue-500 mb-2 ${
                        index === 0 ? 'ring-2 ring-blue-400' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="text-blue-400 text-sm font-medium">
                            #{index + 1}
                          </div>
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: PROCESS_STATE_COLORS[process.state] }}
                          />
                          <span className="text-white font-medium">{process.name}</span>
                          <span className="text-gray-400 text-sm">#{process.id.slice(-4)}</span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm">
                          <span className="text-gray-400">
                            Ráfaga: <span className="text-white">{process.burstTime}</span>
                          </span>
                          <span className="text-gray-400">
                            Restante: <span className="text-white">{process.remainingTime}</span>
                          </span>
                          <span className="text-gray-400">
                            Prioridad: <span className="text-white">{process.priority}</span>
                          </span>
                          <span className="text-gray-400">
                            Llegada: <span className="text-white">{process.arrivalTime}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Show all other processes */}
              <h4 className="text-md font-medium text-white mb-2">Todos los Procesos</h4>
              {processes.map((process) => (
                <div
                  key={process.id}
                  className={`bg-gray-700 rounded-lg p-3 border-l-4 transition-colors ${
                    process.id === currentProcess?.id ? 'border-green-500' : 'border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: PROCESS_STATE_COLORS[process.state] }}
                      />
                      <span className="text-white font-medium">{process.name}</span>
                      <span className="text-gray-400 text-sm">#{process.id.slice(-4)}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        process.state === ProcessState.RUNNING ? 'bg-green-600 text-white' :
                        process.state === ProcessState.READY ? 'bg-blue-600 text-white' :
                        process.state === ProcessState.BLOCKED ? 'bg-yellow-600 text-white' :
                        process.state === ProcessState.TERMINATED ? 'bg-red-600 text-white' :
                        'bg-gray-600 text-white'
                      }`}>
                        {process.state}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm">
                      <span className="text-gray-400">
                        Ráfaga: <span className="text-white">{process.burstTime}</span>
                      </span>
                      <span className="text-gray-400">
                        Restante: <span className="text-white">{process.remainingTime}</span>
                      </span>
                      <span className="text-gray-400">
                        Prioridad: <span className="text-white">{process.priority}</span>
                      </span>
                      <span className="text-gray-400">
                        Memoria: <span className="text-white">{(process.memorySize / 1024).toFixed(1)}KB</span>
                      </span>
                    </div>
                  </div>
                  {(process.currentIOOperation || process.currentSystemCall) && (
                    <div className="mt-2 text-xs text-gray-400 flex items-center space-x-4">
                      {process.currentIOOperation && (
                        <div className="flex items-center space-x-1">
                          <HardDrive size={12} />
                          <span>E/S: {process.currentIOOperation.type} (Restante: {process.currentIOOperation.remainingTime}s)</span>
                        </div>
                      )}
                      {process.currentSystemCall && (
                        <div className="flex items-center space-x-1">
                          <Zap size={12} />
                          <span>SysCall: {process.currentSystemCall.type} (Restante: {process.currentSystemCall.remainingTime}s)</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      <ProcessForm
        isOpen={showProcessForm}
        onClose={() => setShowProcessForm(false)}
        onSubmit={handleCreateCustomProcess}
      />
    </>
  );
};