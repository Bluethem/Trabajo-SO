import React, { useState } from 'react';
import { MemoryBlock, MemoryAllocationAlgorithm, PageReplacementAlgorithm, PageFrame } from '../types';
import { PAGE_SIZE, MIN_FRAME_COUNT, MAX_FRAME_COUNT } from '../utils/constants';
import { Eye, Clock, RefreshCw, Database } from 'lucide-react';

interface MemoryManagerProps {
  memoryBlocks: MemoryBlock[];
  frameTable: boolean[];
  frameCount: number;
  algorithm: MemoryAllocationAlgorithm;
  pageReplacementAlgorithm: PageReplacementAlgorithm;
  pageFrames: PageFrame[];
  onAlgorithmChange: (algorithm: MemoryAllocationAlgorithm) => void;
  onPageReplacementAlgorithmChange: (algorithm: PageReplacementAlgorithm) => void;
  onFrameCountChange: (frameCount: number) => boolean;
  utilization: number;
  fragmentation: number;
  totalMemory: number;
  isSimulationRunning: boolean;
}

export const MemoryManager: React.FC<MemoryManagerProps> = ({
  memoryBlocks,
  frameTable,
  frameCount,
  algorithm,
  pageReplacementAlgorithm,
  pageFrames,
  onAlgorithmChange,
  onPageReplacementAlgorithmChange,
  onFrameCountChange,
  utilization,
  fragmentation,
  totalMemory,
  isSimulationRunning
}) => {
  const [tempFrameCount, setTempFrameCount] = React.useState(frameCount);
  const [frameCountError, setFrameCountError] = React.useState('');
  const [showPageDetails, setShowPageDetails] = useState(false);

  React.useEffect(() => {
    setTempFrameCount(frameCount);
  }, [frameCount]);

  const handleFrameCountChange = (newCount: number) => {
    setTempFrameCount(newCount);
    setFrameCountError('');

    if (newCount < MIN_FRAME_COUNT || newCount > MAX_FRAME_COUNT) {
      setFrameCountError(`El número de marcos debe estar entre ${MIN_FRAME_COUNT} y ${MAX_FRAME_COUNT}`);
      return;
    }

    if (!isSimulationRunning) {
      const success = onFrameCountChange(newCount);
      if (!success) {
        setFrameCountError('No se puede cambiar: hay procesos usando marcos que serían eliminados');
      }
    }
  };

  const getBlockColor = (block: MemoryBlock): string => {
    if (!block.allocated) return '#374151'; // Gris para bloques libres
    
    const colors = [
      '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#F97316', '#06B6D4'
    ];
    const hash = block.processId?.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) || 0;
    return colors[hash % colors.length];
  };

  const getBlockWidth = (block: MemoryBlock): number => {
    return (block.size / totalMemory) * 100;
  };

  const renderFrameTable = () => {
    const rows = [];
    const framesPerRow = Math.min(32, frameCount); // Máximo 32 marcos por fila
    const totalRows = Math.ceil(frameCount / framesPerRow);
    
    for (let row = 0; row < totalRows; row++) {
      const startIndex = row * framesPerRow;
      const endIndex = Math.min(startIndex + framesPerRow, frameCount);
      
      rows.push(
        <div key={row} className="flex gap-1 mb-2 justify-start">
          {frameTable.slice(startIndex, endIndex).map((occupied, index) => (
            <div
              key={startIndex + index}
              className={`w-3 h-3 rounded border ${
                occupied 
                  ? 'bg-blue-500 border-blue-400' 
                  : 'bg-gray-600 border-gray-500'
              }`}
              title={`Marco ${startIndex + index}: ${occupied ? 'Ocupado' : 'Libre'}`}
            />
          ))}
        </div>
      );
    }
    
    return rows;
  };

  const renderPageDetails = () => {
    const allocatedPages = pageFrames.filter(frame => frame.allocated);
    
    if (allocatedPages.length === 0) {
      return (
        <div className="text-gray-400 text-center py-4">
          No hay páginas cargadas en memoria
        </div>
      );
    }

    switch (pageReplacementAlgorithm) {
      case PageReplacementAlgorithm.FIFO:
        return (
          <div className="space-y-2">
            <h4 className="text-white font-medium">Cola de Páginas (FIFO)</h4>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {allocatedPages
                .sort((a, b) => a.loadTime - b.loadTime)
                .map((frame, index) => (
                <div key={frame.frameNumber} className="bg-gray-600 rounded p-2 flex justify-between items-center">
                  <div>
                    <span className="text-white text-sm">
                      Marco {frame.frameNumber} - {frame.processName} (Página {frame.pageNumber})
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-gray-300 text-xs">
                      Posición en cola: {index + 1}
                    </div>
                    <div className="text-gray-400 text-xs">
                      Cargado: {frame.loadTime}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case PageReplacementAlgorithm.SECOND_CHANCE:
        return (
          <div className="space-y-2">
            <h4 className="text-white font-medium">Cola de Páginas (Second Chance)</h4>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {allocatedPages
                .sort((a, b) => a.loadTime - b.loadTime)
                .map((frame) => (
                <div key={frame.frameNumber} className="bg-gray-600 rounded p-2 flex justify-between items-center">
                  <div>
                    <span className="text-white text-sm">
                      Marco {frame.frameNumber} - {frame.processName} (Página {frame.pageNumber})
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${
                      frame.referenceBit ? 'bg-green-500' : 'bg-red-500'
                    }`} title={`Bit de Referencia: ${frame.referenceBit ? '1' : '0'}`} />
                    <span className="text-gray-300 text-xs">
                      R: {frame.referenceBit ? '1' : '0'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case PageReplacementAlgorithm.NRU:
        return (
          <div className="space-y-2">
            <h4 className="text-white font-medium">Páginas con Bits R/M (NRU)</h4>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {allocatedPages.map((frame) => {
                const pageClass = 
                  !frame.referenceBit && !frame.modifyBit ? 0 :
                  !frame.referenceBit && frame.modifyBit ? 1 :
                  frame.referenceBit && !frame.modifyBit ? 2 : 3;
                
                return (
                  <div key={frame.frameNumber} className="bg-gray-600 rounded p-2 flex justify-between items-center">
                    <div>
                      <span className="text-white text-sm">
                        Marco {frame.frameNumber} - {frame.processName} (Página {frame.pageNumber})
                      </span>
                      <div className="text-xs text-gray-300">Clase {pageClass}</div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1">
                        <div className={`w-3 h-3 rounded-full ${
                          frame.referenceBit ? 'bg-green-500' : 'bg-red-500'
                        }`} />
                        <span className="text-gray-300 text-xs">R: {frame.referenceBit ? '1' : '0'}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div className={`w-3 h-3 rounded-full ${
                          frame.modifyBit ? 'bg-yellow-500' : 'bg-red-500'
                        }`} />
                        <span className="text-gray-300 text-xs">M: {frame.modifyBit ? '1' : '0'}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case PageReplacementAlgorithm.LRU:
        return (
          <div className="space-y-2">
            <h4 className="text-white font-medium">Páginas con Tiempo de Acceso (LRU)</h4>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {allocatedPages
                .sort((a, b) => b.lastAccessTime - a.lastAccessTime)
                .map((frame) => (
                <div key={frame.frameNumber} className="bg-gray-600 rounded p-2 flex justify-between items-center">
                  <div>
                    <span className="text-white text-sm">
                      Marco {frame.frameNumber} - {frame.processName} (Página {frame.pageNumber})
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-gray-300 text-xs">
                      Último acceso: {frame.lastAccessTime}
                    </div>
                    <div className="text-gray-400 text-xs">
                      Cargado: {frame.loadTime}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const shouldShowDetailsButton = () => {
    return pageFrames.filter(frame => frame.allocated).length > 0;
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Gestión de Memoria</h2>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-300">
            Utilización: <span className="text-white font-medium">{utilization.toFixed(1)}%</span>
          </div>
          <div className="text-sm text-gray-300">
            Fragmentación: <span className="text-white font-medium">{fragmentation}</span>
          </div>
          <div className="text-sm text-gray-300">
            Total: <span className="text-white font-medium">{(totalMemory / 1024).toFixed(0)}KB</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-300">
            Algoritmo de Asignación
          </label>
          <select
            value={algorithm}
            onChange={(e) => onAlgorithmChange(e.target.value as MemoryAllocationAlgorithm)}
            className="w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {Object.values(MemoryAllocationAlgorithm).map(alg => (
              <option key={alg} value={alg}>{alg}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-300">
            Algoritmo de Reemplazo
          </label>
          <select
            value={pageReplacementAlgorithm}
            onChange={(e) => onPageReplacementAlgorithmChange(e.target.value as PageReplacementAlgorithm)}
            className="w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {Object.values(PageReplacementAlgorithm).map(alg => (
              <option key={alg} value={alg}>{alg}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-300">
            Número de Marcos ({MIN_FRAME_COUNT}-{MAX_FRAME_COUNT})
          </label>
          <input
            type="number"
            min={MIN_FRAME_COUNT}
            max={MAX_FRAME_COUNT}
            value={tempFrameCount}
            onChange={(e) => handleFrameCountChange(parseInt(e.target.value) || MIN_FRAME_COUNT)}
            disabled={isSimulationRunning}
            className={`w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
              frameCountError 
                ? 'focus:ring-red-500 border border-red-500' 
                : 'focus:ring-blue-500'
            } ${isSimulationRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
          />
          {frameCountError && (
            <p className="text-red-400 text-xs mt-1">{frameCountError}</p>
          )}
          {isSimulationRunning && (
            <p className="text-yellow-400 text-xs mt-1">
              Pausa la simulación para cambiar el número de marcos
            </p>
          )}
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-300">
            Tamaño de Página
          </label>
          <div className="bg-gray-700 text-white rounded-lg px-3 py-2">
            {(PAGE_SIZE / 1024).toFixed(0)}KB
          </div>
        </div>
      </div>

      {shouldShowDetailsButton() && (
        <div className="flex justify-end">
          <button
            onClick={() => setShowPageDetails(!showPageDetails)}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
          >
            <Eye size={16} />
            <span>{showPageDetails ? 'Ocultar' : 'Ver'} Detalles de Páginas</span>
          </button>
        </div>
      )}

      {showPageDetails && shouldShowDetailsButton() && (
        <div className="bg-gray-700 rounded-lg p-4">
          {renderPageDetails()}
        </div>
      )}

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Distribución de Memoria</h3>
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center mb-2">
            <span className="text-sm text-gray-300">0x0000</span>
            <div className="flex-1 mx-2 h-8 bg-gray-600 rounded flex">
              {memoryBlocks.map((block, index) => (
                <div
                  key={block.id}
                  className="h-full flex items-center justify-center text-xs text-white font-medium rounded transition-colors"
                  style={{
                    backgroundColor: getBlockColor(block),
                    width: `${getBlockWidth(block)}%`,
                    minWidth: '2px'
                  }}
                  title={`${block.allocated ? block.processName : 'Libre'} - ${block.size} bytes`}
                >
                  {getBlockWidth(block) > 5 && (
                    <span className="truncate px-1">
                      {block.allocated ? block.processName : 'Libre'}
                    </span>
                  )}
                </div>
              ))}
            </div>
            <span className="text-sm text-gray-300">0x{totalMemory.toString(16).toUpperCase()}</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Bloques de Memoria</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-48 overflow-y-auto">
          {memoryBlocks.map((block) => (
            <div
              key={block.id}
              className={`bg-gray-700 rounded-lg p-3 border-l-4 ${
                block.allocated ? 'border-blue-500' : 'border-gray-500'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-medium">
                  {block.allocated ? block.processName : 'Bloque Libre'}
                </span>
                <span className={`text-xs px-2 py-1 rounded ${
                  block.allocated 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-600 text-gray-300'
                }`}>
                  {block.allocated ? 'Asignado' : 'Libre'}
                </span>
              </div>
              <div className="text-sm text-gray-300 space-y-1">
                <div>Inicio: 0x{block.startAddress.toString(16).toUpperCase()}</div>
                <div>Tamaño: {(block.size / 1024).toFixed(1)}KB</div>
                <div>Fin: 0x{(block.startAddress + block.size - 1).toString(16).toUpperCase()}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Tabla de Marcos</h3>
          <div className="text-sm text-gray-400">
            {frameTable.filter(Boolean).length} / {frameCount} marcos utilizados
          </div>
        </div>
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="max-h-48 overflow-y-auto">
            {renderFrameTable()}
          </div>
          <div className="mt-2 flex items-center space-x-4 text-xs text-gray-400">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-blue-500 rounded"></div>
              <span>Ocupado</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-gray-600 rounded"></div>
              <span>Libre</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};