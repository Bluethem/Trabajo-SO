import React from 'react';
import { Interrupt, InterruptType } from '../types';
import { INTERRUPT_COLORS } from '../utils/constants';
import { Zap, Clock, Monitor, Keyboard, Mouse, HardDrive, Wifi, AlertTriangle } from 'lucide-react';

interface InterruptManagerProps {
  interrupts: Interrupt[];
  interruptQueue: Interrupt[];
  currentInterrupt: Interrupt | null;
  contextSwitchCount: number;
  onClearHandled: () => void;
}

export const InterruptManager: React.FC<InterruptManagerProps> = ({
  interrupts,
  interruptQueue,
  currentInterrupt,
  contextSwitchCount,
  onClearHandled
}) => {
  const getInterruptIcon = (type: InterruptType) => {
    const iconProps = { size: 16, className: "text-white" };
    
    switch (type) {
      case InterruptType.TIMER:
        return <Clock {...iconProps} />;
      case InterruptType.IO:
        return <Monitor {...iconProps} />;
      case InterruptType.KEYBOARD:
        return <Keyboard {...iconProps} />;
      case InterruptType.MOUSE:
        return <Mouse {...iconProps} />;
      case InterruptType.DISK:
        return <HardDrive {...iconProps} />;
      case InterruptType.NETWORK:
        return <Wifi {...iconProps} />;
      case InterruptType.PAGE_FAULT:
        return <AlertTriangle {...iconProps} />;
      case InterruptType.SYSTEM_CALL:
        return <Zap {...iconProps} />;
      default:
        return <Monitor {...iconProps} />;
    }
  };

  const getInterruptCounts = () => {
    const counts = interrupts.reduce((acc, interrupt) => {
      acc[interrupt.type] = (acc[interrupt.type] || 0) + 1;
      return acc;
    }, {} as Record<InterruptType, number>);
    
    return Object.values(InterruptType).map(type => ({
      type,
      count: counts[type] || 0,
      color: INTERRUPT_COLORS[type]
    }));
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Gestión de Interrupciones</h2>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-300">
            Cambios de Contexto: <span className="text-white font-medium">{contextSwitchCount}</span>
          </div>
          <button
            onClick={onClearHandled}
            className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-medium transition-colors"
          >
            Limpiar Procesadas
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {getInterruptCounts().map(({ type, count, color }) => (
          <div key={type} className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              {getInterruptIcon(type)}
              <span className="text-white text-sm font-medium">{type}</span>
            </div>
            <div className="text-2xl font-bold text-white">{count}</div>
          </div>
        ))}
      </div>

      {currentInterrupt && (
        <div className="bg-gray-700 rounded-lg p-4 border-l-4 border-yellow-500">
          <h3 className="text-lg font-semibold text-white mb-2">Procesando Actualmente</h3>
          <div className="flex items-center space-x-3">
            {getInterruptIcon(currentInterrupt.type)}
            <div>
              <div className="text-white font-medium">{currentInterrupt.type}</div>
              <div className="text-gray-400 text-sm">
                Prioridad: {currentInterrupt.priority} | 
                ID: {currentInterrupt.id.slice(-8)}
              </div>
              {currentInterrupt.description && (
                <div className="text-gray-300 text-sm mt-1">
                  {currentInterrupt.description}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Cola de Interrupciones</h3>
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {interruptQueue.length === 0 ? (
            <div className="text-gray-400 text-center py-4">No hay interrupciones en cola</div>
          ) : (
            interruptQueue.map((interrupt) => (
              <div
                key={interrupt.id}
                className="bg-gray-700 rounded-lg p-3 flex items-center space-x-3"
              >
                {getInterruptIcon(interrupt.type)}
                <div className="flex-1">
                  <div className="text-white font-medium">{interrupt.type}</div>
                  <div className="text-gray-400 text-sm">
                    Prioridad: {interrupt.priority}
                  </div>
                  {interrupt.description && (
                    <div className="text-gray-300 text-xs mt-1">
                      {interrupt.description}
                    </div>
                  )}
                </div>
                <div className="text-gray-400 text-xs">
                  {new Date(interrupt.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Interrupciones Recientes</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {interrupts.slice(-15).reverse().map((interrupt) => (
            <div
              key={interrupt.id}
              className={`bg-gray-700 rounded-lg p-3 flex items-center space-x-3 ${
                interrupt.handled ? 'opacity-60' : ''
              }`}
            >
              {getInterruptIcon(interrupt.type)}
              <div className="flex-1">
                <div className="text-white font-medium">{interrupt.type}</div>
                <div className="text-gray-400 text-sm">
                  Prioridad: {interrupt.priority}
                  {interrupt.processId && ` | Proceso: ${interrupt.processId.slice(-4)}`}
                </div>
                {interrupt.description && (
                  <div className="text-gray-300 text-xs mt-1">
                    {interrupt.description}
                  </div>
                )}
              </div>
              <div className="text-right">
                <div className={`text-xs px-2 py-1 rounded ${
                  interrupt.handled 
                    ? 'bg-green-600 text-white' 
                    : 'bg-yellow-600 text-white'
                }`}>
                  {interrupt.handled ? 'Procesada' : 'Pendiente'}
                </div>
                <div className="text-gray-400 text-xs mt-1">
                  {new Date(interrupt.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};