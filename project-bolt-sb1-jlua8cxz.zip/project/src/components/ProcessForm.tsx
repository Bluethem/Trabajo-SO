import React, { useState } from 'react';
import { X, Plus } from 'lucide-react';

interface ProcessFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (name: string, burstTime: number, priority: number, memorySize: number) => void;
}

export const ProcessForm: React.FC<ProcessFormProps> = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [formData, setFormData] = useState({
    name: '',
    burstTime: 5,
    priority: 5,
    memorySize: 4096
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'El nombre del proceso es requerido';
    }

    if (formData.burstTime < 1 || formData.burstTime > 100) {
      newErrors.burstTime = 'El tiempo de ráfaga debe estar entre 1 y 100';
    }

    if (formData.priority < 1 || formData.priority > 10) {
      newErrors.priority = 'La prioridad debe estar entre 1 y 10';
    }

    if (formData.memorySize < 512 || formData.memorySize > 32768) {
      newErrors.memorySize = 'El tamaño de memoria debe estar entre 512 bytes y 32KB';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(
        formData.name.trim(),
        formData.burstTime,
        formData.priority,
        formData.memorySize
      );
      
      // Reset form
      setFormData({
        name: '',
        burstTime: 5,
        priority: 5,
        memorySize: 4096
      });
      setErrors({});
      onClose();
    }
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Crear Nuevo Proceso</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Nombre del Proceso
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className={`w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
                errors.name ? 'focus:ring-red-500 border border-red-500' : 'focus:ring-blue-500'
              }`}
              placeholder="Ej: Mi Aplicación"
            />
            {errors.name && (
              <p className="text-red-400 text-sm mt-1">{errors.name}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Tiempo de Ráfaga (1-100)
            </label>
            <input
              type="number"
              min="1"
              max="100"
              value={formData.burstTime}
              onChange={(e) => handleInputChange('burstTime', parseInt(e.target.value) || 1)}
              className={`w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
                errors.burstTime ? 'focus:ring-red-500 border border-red-500' : 'focus:ring-blue-500'
              }`}
            />
            {errors.burstTime && (
              <p className="text-red-400 text-sm mt-1">{errors.burstTime}</p>
            )}
            <p className="text-gray-400 text-xs mt-1">
              Tiempo que el proceso necesita para completarse
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Prioridad (1-10, menor número = mayor prioridad)
            </label>
            <input
              type="number"
              min="1"
              max="10"
              value={formData.priority}
              onChange={(e) => handleInputChange('priority', parseInt(e.target.value) || 1)}
              className={`w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
                errors.priority ? 'focus:ring-red-500 border border-red-500' : 'focus:ring-blue-500'
              }`}
            />
            {errors.priority && (
              <p className="text-red-400 text-sm mt-1">{errors.priority}</p>
            )}
            <p className="text-gray-400 text-xs mt-1">
              1 = Prioridad más alta, 10 = Prioridad más baja
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Tamaño de Memoria (bytes)
            </label>
            <select
              value={formData.memorySize}
              onChange={(e) => handleInputChange('memorySize', parseInt(e.target.value))}
              className={`w-full bg-gray-700 text-white rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
                errors.memorySize ? 'focus:ring-red-500 border border-red-500' : 'focus:ring-blue-500'
              }`}
            >
              <option value={512}>512 bytes (0.5KB)</option>
              <option value={1024}>1024 bytes (1KB)</option>
              <option value={2048}>2048 bytes (2KB)</option>
              <option value={4096}>4096 bytes (4KB)</option>
              <option value={8192}>8192 bytes (8KB)</option>
              <option value={12288}>12288 bytes (12KB)</option>
              <option value={16384}>16384 bytes (16KB)</option>
              <option value={24576}>24576 bytes (24KB)</option>
              <option value={32768}>32768 bytes (32KB)</option>
            </select>
            {errors.memorySize && (
              <p className="text-red-400 text-sm mt-1">{errors.memorySize}</p>
            )}
            <p className="text-gray-400 text-xs mt-1">
              Cantidad de memoria que requiere el proceso
            </p>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              <Plus size={16} />
              <span>Crear Proceso</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};