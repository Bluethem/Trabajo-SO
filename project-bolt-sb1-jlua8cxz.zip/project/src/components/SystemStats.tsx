import React from 'react';
import { SystemStats as SystemStatsType } from '../types';
import { Activity, Cpu, MemoryStick, Zap, Clock, Users, HardDrive } from 'lucide-react';

interface SystemStatsProps {
  stats: SystemStatsType;
}

export const SystemStats: React.FC<SystemStatsProps> = ({ stats }) => {
  const statCards = [
    {
      title: 'Total de Procesos',
      value: stats.totalProcesses,
      icon: Users,
      color: 'bg-blue-600'
    },
    {
      title: 'Procesos Ejecutándose',
      value: stats.runningProcesses,
      icon: Activity,
      color: 'bg-green-600'
    },
    {
      title: 'Procesos Listos',
      value: stats.readyProcesses,
      icon: Clock,
      color: 'bg-blue-500'
    },
    {
      title: 'Procesos Bloqueados',
      value: stats.blockedProcesses,
      icon: HardDrive,
      color: 'bg-yellow-600'
    },
    {
      title: 'Utilización de CPU',
      value: `${stats.cpuUtilization.toFixed(1)}%`,
      icon: Cpu,
      color: 'bg-purple-600'
    },
    {
      title: 'Uso de Memoria',
      value: `${stats.memoryUtilization.toFixed(1)}%`,
      icon: MemoryStick,
      color: 'bg-indigo-600'
    }
  ];

  return (
    <div className="bg-gray-800 rounded-lg p-6 space-y-6">
      <h2 className="text-xl font-bold text-white">Estadísticas del Sistema</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((card) => (
          <div key={card.title} className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${card.color}`}>
                <card.icon size={20} className="text-white" />
              </div>
              <div>
                <div className="text-gray-400 text-sm">{card.title}</div>
                <div className="text-white text-xl font-bold">{card.value}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-white mb-3">Distribución de Procesos</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Ejecutando</span>
              <span className="text-green-400 font-medium">{stats.runningProcesses}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Listos</span>
              <span className="text-blue-400 font-medium">{stats.readyProcesses}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Bloqueados</span>
              <span className="text-yellow-400 font-medium">{stats.blockedProcesses}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Terminados</span>
              <span className="text-red-400 font-medium">{stats.terminatedProcesses}</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-white mb-3">Métricas de Rendimiento</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Tiempo Promedio de Espera</span>
              <span className="text-blue-400 font-medium">{stats.averageWaitTime.toFixed(1)}ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Tiempo Promedio de Retorno</span>
              <span className="text-green-400 font-medium">{stats.averageTurnaroundTime.toFixed(1)}ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Cambios de Contexto</span>
              <span className="text-purple-400 font-medium">{stats.contextSwitches}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Eficiencia del Sistema</span>
              <span className="text-orange-400 font-medium">
                {((stats.cpuUtilization + stats.memoryUtilization) / 2).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};