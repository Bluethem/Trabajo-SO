import { useState, useCallback, useEffect } from 'react';
import { Interrupt, InterruptType } from '../types';

export const useInterruptManager = () => {
  const [interrupts, setInterrupts] = useState<Interrupt[]>([]);
  const [interruptQueue, setInterruptQueue] = useState<Interrupt[]>([]);
  const [currentInterrupt, setCurrentInterrupt] = useState<Interrupt | null>(null);
  const [contextSwitchCount, setContextSwitchCount] = useState(0);

  const createInterrupt = useCallback((
    type: InterruptType,
    processId?: string,
    priority: number = 5,
    description?: string
  ): Interrupt => {
    return {
      id: `int_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      processId,
      timestamp: Date.now(),
      handled: false,
      priority,
      description
    };
  }, []);

  const addInterrupt = useCallback((interrupt: Interrupt) => {
    setInterrupts(prev => [...prev, interrupt]);
    
    // Add to queue sorted by priority (lower number = higher priority)
    setInterruptQueue(prev => {
      const newQueue = [...prev, interrupt];
      return newQueue.sort((a, b) => a.priority - b.priority);
    });
  }, []);

  const addTimerInterrupt = useCallback((processId: string, processName: string) => {
    const interrupt = createInterrupt(
      InterruptType.TIMER,
      processId,
      1, // High priority for timer interrupts
      `Quantum agotado para ${processName}`
    );
    addInterrupt(interrupt);
  }, [createInterrupt, addInterrupt]);

  const addIOInterrupt = useCallback((processId: string, processName: string, ioType: string) => {
    const interrupt = createInterrupt(
      InterruptType.IO,
      processId,
      4, // Medium priority for I/O
      `${processName} solicita ${ioType}`
    );
    addInterrupt(interrupt);
  }, [createInterrupt, addInterrupt]);

  const addSystemCallInterrupt = useCallback((processId: string, processName: string, callType: string) => {
    const interrupt = createInterrupt(
      InterruptType.SYSTEM_CALL,
      processId,
      3, // Medium-high priority for system calls
      `${processName} realiza ${callType}`
    );
    addInterrupt(interrupt);
  }, [createInterrupt, addInterrupt]);

  const generateRandomInterrupt = useCallback(() => {
    const interruptTypes = [
      InterruptType.KEYBOARD,
      InterruptType.MOUSE,
      InterruptType.DISK,
      InterruptType.NETWORK,
      InterruptType.PAGE_FAULT
    ];
    const randomType = interruptTypes[Math.floor(Math.random() * interruptTypes.length)];
    const priorities = {
      [InterruptType.TIMER]: 1,
      [InterruptType.PAGE_FAULT]: 2,
      [InterruptType.SYSTEM_CALL]: 3,
      [InterruptType.IO]: 4,
      [InterruptType.KEYBOARD]: 5,
      [InterruptType.MOUSE]: 6,
      [InterruptType.DISK]: 7,
      [InterruptType.NETWORK]: 8
    };
    
    const interrupt = createInterrupt(randomType, undefined, priorities[randomType]);
    return interrupt;
  }, [createInterrupt]);

  const processNextInterrupt = useCallback(() => {
    if (interruptQueue.length === 0) return;

    const nextInterrupt = interruptQueue[0];
    setCurrentInterrupt(nextInterrupt);
    setInterruptQueue(prev => prev.slice(1));
    setContextSwitchCount(prev => prev + 1);

    // Simulate interrupt handling
    setTimeout(() => {
      setInterrupts(prev => prev.map(int => 
        int.id === nextInterrupt.id 
          ? { ...int, handled: true }
          : int
      ));
      setCurrentInterrupt(null);
    }, 1500); // Reduced handling time for better responsiveness
  }, [interruptQueue]);

  const handleInterrupt = useCallback((interrupt: Interrupt) => {
    setInterrupts(prev => prev.map(int => 
      int.id === interrupt.id 
        ? { ...int, handled: true }
        : int
    ));
  }, []);

  const clearHandledInterrupts = useCallback(() => {
    setInterrupts(prev => prev.filter(int => !int.handled));
  }, []);

  // Auto-process interrupts
  useEffect(() => {
    if (interruptQueue.length > 0 && !currentInterrupt) {
      const timer = setTimeout(processNextInterrupt, 500); // Faster processing
      return () => clearTimeout(timer);
    }
  }, [interruptQueue, currentInterrupt, processNextInterrupt]);

  // Generate random system interrupts (less frequently)
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() < 0.2) { // 20% chance every 4 seconds
        const interrupt = generateRandomInterrupt();
        addInterrupt(interrupt);
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [generateRandomInterrupt, addInterrupt]);

  return {
    interrupts,
    interruptQueue,
    currentInterrupt,
    contextSwitchCount,
    addInterrupt,
    addTimerInterrupt,
    addIOInterrupt,
    addSystemCallInterrupt,
    handleInterrupt,
    clearHandledInterrupts,
    createInterrupt
  };
};