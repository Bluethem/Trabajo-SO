import { useState, useCallback, useEffect } from 'react';
import { MemoryBlock, Process, MemoryAllocationAlgorithm, PageTableEntry, PageReplacementAlgorithm, PageFrame } from '../types';
import { MEMORY_SIZE, PAGE_SIZE, DEFAULT_FRAME_COUNT, MIN_FRAME_COUNT, MAX_FRAME_COUNT } from '../utils/constants';

export const useMemoryManager = () => {
  const [memoryBlocks, setMemoryBlocks] = useState<MemoryBlock[]>([]);
  const [algorithm, setAlgorithm] = useState<MemoryAllocationAlgorithm>(MemoryAllocationAlgorithm.FIRST_FIT);
  const [pageReplacementAlgorithm, setPageReplacementAlgorithm] = useState<PageReplacementAlgorithm>(PageReplacementAlgorithm.FIFO);
  const [frameCount, setFrameCount] = useState<number>(DEFAULT_FRAME_COUNT);
  const [frameTable, setFrameTable] = useState<boolean[]>(new Array(DEFAULT_FRAME_COUNT).fill(false));
  const [pageFrames, setPageFrames] = useState<PageFrame[]>([]);
  const [allocatedProcesses, setAllocatedProcesses] = useState<Set<string>>(new Set());
  const [currentTime, setCurrentTime] = useState<number>(0);

  // Initialize page frames
  useEffect(() => {
    const newPageFrames: PageFrame[] = [];
    for (let i = 0; i < frameCount; i++) {
      newPageFrames.push({
        frameNumber: i,
        allocated: false,
        referenceBit: false,
        modifyBit: false,
        lastAccessTime: 0,
        loadTime: 0,
        secondChance: false
      });
    }
    setPageFrames(newPageFrames);
  }, [frameCount]);

  // Update frame table when frame count changes
  useEffect(() => {
    const newFrameTable = new Array(frameCount).fill(false);
    // Preserve existing frame allocations if possible
    if (frameTable.length > 0) {
      for (let i = 0; i < Math.min(frameTable.length, frameCount); i++) {
        newFrameTable[i] = frameTable[i];
      }
    }
    setFrameTable(newFrameTable);
  }, [frameCount]);

  useEffect(() => {
    // Initialize memory with one large free block
    const totalMemory = frameCount * PAGE_SIZE;
    setMemoryBlocks([{
      id: 'initial',
      startAddress: 0,
      size: totalMemory,
      allocated: false
    }]);
  }, [frameCount]);

  // Simplified time increment - only one timer for memory manager
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(prev => prev + 1);
      
      // Simulate random page accesses less frequently
      if (Math.random() < 0.3) { // 30% chance every 3 seconds
        setPageFrames(prev => {
          const allocatedFrames = prev.filter(frame => frame.allocated);
          if (allocatedFrames.length > 0) {
            const randomFrame = allocatedFrames[Math.floor(Math.random() * allocatedFrames.length)];
            return prev.map(frame => 
              frame.frameNumber === randomFrame.frameNumber
                ? {
                    ...frame,
                    referenceBit: true,
                    modifyBit: Math.random() < 0.3, // 30% chance of modification
                    lastAccessTime: prev.length // Use array length as time reference
                  }
                : frame
            );
          }
          return prev;
        });
      }
    }, 3000); // Every 3 seconds

    return () => clearInterval(interval);
  }, []);

  const updateFrameCount = useCallback((newFrameCount: number) => {
    if (newFrameCount < MIN_FRAME_COUNT || newFrameCount > MAX_FRAME_COUNT) {
      return false;
    }

    // Check if reducing frame count would affect allocated processes
    if (newFrameCount < frameCount) {
      const allocatedFrames = frameTable.slice(newFrameCount).some(frame => frame);
      if (allocatedFrames) {
        console.warn('No se puede reducir el número de marcos: hay procesos usando marcos que serían eliminados');
        return false;
      }
    }

    setFrameCount(newFrameCount);
    return true;
  }, [frameCount, frameTable]);

  const findVictimFrame = useCallback((): number => {
    const allocatedFrames = pageFrames.filter(frame => frame.allocated);
    
    if (allocatedFrames.length === 0) {
      return -1;
    }

    switch (pageReplacementAlgorithm) {
      case PageReplacementAlgorithm.FIFO:
        // Find the frame that was loaded earliest
        return allocatedFrames.reduce((oldest, current) => 
          current.loadTime < oldest.loadTime ? current : oldest
        ).frameNumber;

      case PageReplacementAlgorithm.SECOND_CHANCE:
        // FIFO with second chance bit
        let candidateFrame = allocatedFrames.reduce((oldest, current) => 
          current.loadTime < oldest.loadTime ? current : oldest
        );
        
        // If reference bit is set, give it a second chance
        while (candidateFrame.referenceBit) {
          setPageFrames(prev => prev.map(frame => 
            frame.frameNumber === candidateFrame.frameNumber
              ? { ...frame, referenceBit: false, loadTime: currentTime }
              : frame
          ));
          
          // Find next oldest frame
          const remainingFrames = allocatedFrames.filter(f => f.frameNumber !== candidateFrame.frameNumber);
          if (remainingFrames.length === 0) break;
          
          candidateFrame = remainingFrames.reduce((oldest, current) => 
            current.loadTime < oldest.loadTime ? current : oldest
          );
        }
        return candidateFrame.frameNumber;

      case PageReplacementAlgorithm.NRU:
        // Classify pages into 4 classes based on reference and modify bits
        const class0 = allocatedFrames.filter(f => !f.referenceBit && !f.modifyBit);
        const class1 = allocatedFrames.filter(f => !f.referenceBit && f.modifyBit);
        const class2 = allocatedFrames.filter(f => f.referenceBit && !f.modifyBit);
        const class3 = allocatedFrames.filter(f => f.referenceBit && f.modifyBit);
        
        // Select from lowest non-empty class
        if (class0.length > 0) return class0[Math.floor(Math.random() * class0.length)].frameNumber;
        if (class1.length > 0) return class1[Math.floor(Math.random() * class1.length)].frameNumber;
        if (class2.length > 0) return class2[Math.floor(Math.random() * class2.length)].frameNumber;
        return class3[Math.floor(Math.random() * class3.length)].frameNumber;

      case PageReplacementAlgorithm.LRU:
        // Find the frame that was accessed least recently
        return allocatedFrames.reduce((lru, current) => 
          current.lastAccessTime < lru.lastAccessTime ? current : lru
        ).frameNumber;

      default:
        return allocatedFrames[0].frameNumber;
    }
  }, [pageFrames, pageReplacementAlgorithm, currentTime]);

  const allocateMemory = useCallback((process: Process): boolean => {
    // Check if process already has memory allocated
    if (allocatedProcesses.has(process.id)) {
      return true; // Already allocated
    }

    const requiredSize = process.memorySize;
    const totalMemory = frameCount * PAGE_SIZE;
    
    if (requiredSize > totalMemory) {
      console.warn(`No se puede asignar memoria para ${process.name}: Requiere más memoria que la disponible total`);
      return false;
    }

    let bestBlock: MemoryBlock | null = null;
    let bestIndex = -1;

    const freeBlocks = memoryBlocks.filter(block => !block.allocated && block.size >= requiredSize);
    
    if (freeBlocks.length === 0) {
      console.warn(`No se puede asignar memoria para ${process.name}: No hay bloques libres suficientes`);
      return false; // No suitable block found
    }

    switch (algorithm) {
      case MemoryAllocationAlgorithm.FIRST_FIT:
        bestBlock = freeBlocks[0];
        bestIndex = memoryBlocks.findIndex(block => block.id === bestBlock!.id);
        break;

      case MemoryAllocationAlgorithm.BEST_FIT:
        bestBlock = freeBlocks.reduce((best, current) => 
          current.size < best.size ? current : best
        );
        bestIndex = memoryBlocks.findIndex(block => block.id === bestBlock!.id);
        break;

      case MemoryAllocationAlgorithm.WORST_FIT:
        bestBlock = freeBlocks.reduce((worst, current) => 
          current.size > worst.size ? current : worst
        );
        bestIndex = memoryBlocks.findIndex(block => block.id === bestBlock!.id);
        break;
    }

    if (!bestBlock || bestIndex === -1) {
      console.warn(`No se puede asignar memoria para ${process.name}: No se encontró bloque adecuado`);
      return false;
    }

    // Check if allocation would exceed frame boundaries
    const startFrame = Math.floor(bestBlock.startAddress / PAGE_SIZE);
    const pagesNeeded = Math.ceil(requiredSize / PAGE_SIZE);
    
    if (startFrame + pagesNeeded > frameCount) {
      console.warn(`No se puede asignar memoria para ${process.name}: Excede el número de marcos disponibles`);
      return false;
    }

    // Allocate frames for the process
    let framesAllocated = 0;
    const allocatedFrameNumbers: number[] = [];

    for (let i = 0; i < pagesNeeded; i++) {
      let frameToUse = -1;
      
      // First, try to find a free frame
      const freeFrame = pageFrames.find(frame => !frame.allocated);
      if (freeFrame) {
        frameToUse = freeFrame.frameNumber;
      } else {
        // No free frames, use page replacement algorithm
        frameToUse = findVictimFrame();
        if (frameToUse === -1) {
          console.warn(`No se puede asignar memoria para ${process.name}: No hay marcos disponibles`);
          return false;
        }
      }

      allocatedFrameNumbers.push(frameToUse);
      framesAllocated++;
    }

    // Update page frames
    allocatedFrameNumbers.forEach((frameNumber, pageIndex) => {
      setPageFrames(prev => prev.map(frame => 
        frame.frameNumber === frameNumber
          ? {
              ...frame,
              pageNumber: pageIndex,
              processId: process.id,
              processName: process.name,
              allocated: true,
              referenceBit: true,
              modifyBit: false,
              lastAccessTime: currentTime,
              loadTime: currentTime,
              secondChance: false
            }
          : frame
      ));
    });

    // Allocate the block
    const newBlocks = [...memoryBlocks];
    const allocatedBlock: MemoryBlock = {
      id: `alloc_${process.id}`,
      startAddress: bestBlock.startAddress,
      size: requiredSize,
      allocated: true,
      processId: process.id,
      processName: process.name
    };

    newBlocks[bestIndex] = allocatedBlock;

    // Create remainder block if necessary
    if (bestBlock.size > requiredSize) {
      const remainderBlock: MemoryBlock = {
        id: `remainder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        startAddress: bestBlock.startAddress + requiredSize,
        size: bestBlock.size - requiredSize,
        allocated: false
      };
      newBlocks.splice(bestIndex + 1, 0, remainderBlock);
    }

    setMemoryBlocks(newBlocks);
    setAllocatedProcesses(prev => new Set(prev).add(process.id));
    
    // Update frame table
    for (let i = 0; i < pagesNeeded; i++) {
      const frameNumber = startFrame + i;
      if (frameNumber < frameCount) {
        setFrameTable(prev => {
          const newTable = [...prev];
          newTable[frameNumber] = true;
          return newTable;
        });
      }
    }

    console.log(`Memoria asignada exitosamente para ${process.name}: ${(requiredSize / 1024).toFixed(1)}KB`);
    return true;
  }, [memoryBlocks, algorithm, allocatedProcesses, frameCount, pageFrames, findVictimFrame, currentTime]);

  const deallocateMemory = useCallback((processId: string) => {
    const processBlocks = memoryBlocks.filter(block => block.processId === processId);
    
    if (processBlocks.length === 0) {
      return; // Process not found in memory
    }

    console.log(`Liberando memoria para proceso ${processId}...`);

    // Free page frames for this process
    setPageFrames(prev => prev.map(frame => 
      frame.processId === processId
        ? {
            ...frame,
            pageNumber: undefined,
            processId: undefined,
            processName: undefined,
            allocated: false,
            referenceBit: false,
            modifyBit: false,
            lastAccessTime: 0,
            loadTime: 0,
            secondChance: false
          }
        : frame
    ));

    // Update frame table
    processBlocks.forEach(block => {
      const startFrame = Math.floor(block.startAddress / PAGE_SIZE);
      const framesUsed = Math.ceil(block.size / PAGE_SIZE);
      for (let i = startFrame; i < startFrame + framesUsed && i < frameCount; i++) {
        setFrameTable(prev => {
          const newTable = [...prev];
          newTable[i] = false;
          return newTable;
        });
      }
    });

    // Update memory blocks
    setMemoryBlocks(prev => {
      const newBlocks = prev.map(block => 
        block.processId === processId 
          ? { ...block, allocated: false, processId: undefined, processName: undefined }
          : block
      );

      // Merge adjacent free blocks
      const mergedBlocks: MemoryBlock[] = [];
      let currentBlock = newBlocks[0];

      for (let i = 1; i < newBlocks.length; i++) {
        const nextBlock = newBlocks[i];
        
        if (!currentBlock.allocated && !nextBlock.allocated && 
            currentBlock.startAddress + currentBlock.size === nextBlock.startAddress) {
          // Merge blocks
          currentBlock = {
            ...currentBlock,
            size: currentBlock.size + nextBlock.size,
            id: `merged_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
          };
        } else {
          mergedBlocks.push(currentBlock);
          currentBlock = nextBlock;
        }
      }
      mergedBlocks.push(currentBlock);

      return mergedBlocks;
    });

    // Remove from allocated processes set
    setAllocatedProcesses(prev => {
      const newSet = new Set(prev);
      newSet.delete(processId);
      return newSet;
    });

    console.log(`Memoria liberada exitosamente para proceso ${processId}`);
  }, [memoryBlocks, frameCount]);

  const getMemoryUtilization = useCallback(() => {
    const totalMemory = frameCount * PAGE_SIZE;
    const allocatedMemory = memoryBlocks
      .filter(block => block.allocated)
      .reduce((total, block) => total + block.size, 0);
    return (allocatedMemory / totalMemory) * 100;
  }, [memoryBlocks, frameCount]);

  const getFragmentation = useCallback(() => {
    const freeBlocks = memoryBlocks.filter(block => !block.allocated);
    return freeBlocks.length > 1 ? freeBlocks.length - 1 : 0;
  }, [memoryBlocks]);

  const getAvailableMemory = useCallback(() => {
    return memoryBlocks
      .filter(block => !block.allocated)
      .reduce((total, block) => total + block.size, 0);
  }, [memoryBlocks]);

  const getTotalMemory = useCallback(() => {
    return frameCount * PAGE_SIZE;
  }, [frameCount]);

  return {
    memoryBlocks,
    frameTable,
    frameCount,
    algorithm,
    pageReplacementAlgorithm,
    pageFrames,
    allocateMemory,
    deallocateMemory,
    setAlgorithm,
    setPageReplacementAlgorithm,
    updateFrameCount,
    getMemoryUtilization,
    getFragmentation,
    getAvailableMemory,
    getTotalMemory
  };
};