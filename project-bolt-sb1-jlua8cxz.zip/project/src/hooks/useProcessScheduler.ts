import { useState, useEffect, useCallback, useRef } from 'react';
import { Process, ProcessState, SchedulingAlgorithm, PCB, PageTableEntry, IOOperation, IOType, SystemCall, SystemCallType, RoundRobinConfig } from '../types';
import { TIME_QUANTUM, IO_PROBABILITY, SYSTEM_CALL_PROBABILITY, MIN_IO_DURATION, MAX_IO_DURATION, MIN_SYSCALL_DURATION, MAX_SYSCALL_DURATION } from '../utils/constants';

interface UseProcessSchedulerProps {
  onTimerInterrupt?: (processId: string, processName: string) => void;
  onIOInterrupt?: (processId: string, processName: string, ioType: string) => void;
  onSystemCallInterrupt?: (processId: string, processName: string, callType: string) => void;
}

export const useProcessScheduler = (callbacks?: UseProcessSchedulerProps) => {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [currentProcess, setCurrentProcess] = useState<Process | null>(null);
  const [algorithm, setAlgorithm] = useState<SchedulingAlgorithm>(SchedulingAlgorithm.FCFS);
  const [timeQuantum, setTimeQuantum] = useState(TIME_QUANTUM);
  const [isRunning, setIsRunning] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [quantumRemaining, setQuantumRemaining] = useState(timeQuantum);
  const [roundRobinConfig, setRoundRobinConfig] = useState<RoundRobinConfig>({
    isPreemptive: true,
    orderBy: 'arrival'
  });
  
  // Keep track of Round Robin queue order
  const [roundRobinQueue, setRoundRobinQueue] = useState<string[]>([]);

  // Reset quantum when time quantum changes
  useEffect(() => {
    setQuantumRemaining(timeQuantum);
  }, [timeQuantum]);

  const createIOOperation = useCallback((currentTime: number): IOOperation => {
    const ioTypes = Object.values(IOType);
    const randomType = ioTypes[Math.floor(Math.random() * ioTypes.length)];
    const duration = MIN_IO_DURATION + Math.floor(Math.random() * (MAX_IO_DURATION - MIN_IO_DURATION + 1));
    
    return {
      id: `io_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: randomType,
      duration,
      remainingTime: duration,
      startTime: currentTime
    };
  }, []);

  const createSystemCall = useCallback((currentTime: number): SystemCall => {
    const callTypes = Object.values(SystemCallType);
    const randomType = callTypes[Math.floor(Math.random() * callTypes.length)];
    const duration = MIN_SYSCALL_DURATION + Math.floor(Math.random() * (MAX_SYSCALL_DURATION - MIN_SYSCALL_DURATION + 1));
    
    return {
      id: `syscall_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: randomType,
      duration,
      remainingTime: duration,
      startTime: currentTime
    };
  }, []);

  const createProcess = useCallback((
    name: string,
    burstTime: number,
    priority: number,
    memorySize: number
  ): Process => {
    const id = `proc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const pcb: PCB = {
      processId: id,
      programCounter: 0,
      registers: { AX: 0, BX: 0, CX: 0, DX: 0, SP: 1000, BP: 1000 },
      memoryLimits: { base: 0, limit: memorySize },
      fileHandles: [],
      cpuTime: 0,
      priority
    };

    const pageTableEntries: PageTableEntry[] = [];
    const pagesNeeded = Math.ceil(memorySize / 4096);
    
    for (let i = 0; i < pagesNeeded; i++) {
      pageTableEntries.push({
        pageNumber: i,
        frameNumber: -1,
        valid: false,
        dirty: false,
        referenced: false
      });
    }

    return {
      id,
      name,
      arrivalTime: currentTime,
      burstTime,
      remainingTime: burstTime,
      priority,
      state: ProcessState.NEW,
      memorySize,
      pageTableEntries,
      pcb,
      createdAt: Date.now(),
      waitingTime: 0,
      turnaroundTime: 0,
      ioOperations: [],
      systemCalls: []
    };
  }, [currentTime]);

  const addProcess = useCallback((
    name: string,
    burstTime: number,
    priority: number,
    memorySize: number
  ) => {
    const newProcess = createProcess(name, burstTime, priority, memorySize);
    setProcesses(prev => [...prev, newProcess]);
  }, [createProcess]);

  // Update Round Robin queue when processes change state
  useEffect(() => {
    if (algorithm === SchedulingAlgorithm.RR) {
      const readyProcesses = processes.filter(p => p.state === ProcessState.READY);
      
      // Sort ready processes according to configuration
      const sortedProcesses = roundRobinConfig.orderBy === 'priority'
        ? readyProcesses.sort((a, b) => {
            if (a.priority !== b.priority) {
              return a.priority - b.priority;
            }
            return a.arrivalTime - b.arrivalTime;
          })
        : readyProcesses.sort((a, b) => a.arrivalTime - b.arrivalTime);

      // Update queue maintaining order, but only add new processes that aren't already in queue
      setRoundRobinQueue(prev => {
        const currentQueue = prev.filter(id => 
          readyProcesses.some(p => p.id === id)
        );
        
        // Add new ready processes that aren't in the queue yet
        const newProcessIds = sortedProcesses
          .filter(p => !currentQueue.includes(p.id))
          .map(p => p.id);
        
        return [...currentQueue, ...newProcessIds];
      });
    }
  }, [processes, algorithm, roundRobinConfig]);

  const getNextProcess = useCallback((): Process | null => {
    const readyProcesses = processes.filter(p => p.state === ProcessState.READY);
    if (readyProcesses.length === 0) return null;

    switch (algorithm) {
      case SchedulingAlgorithm.FCFS:
        return readyProcesses.sort((a, b) => a.arrivalTime - b.arrivalTime)[0];
      
      case SchedulingAlgorithm.SJF:
        return readyProcesses.sort((a, b) => a.remainingTime - b.remainingTime)[0];
      
      case SchedulingAlgorithm.PRIORITY:
        return readyProcesses.sort((a, b) => a.priority - b.priority)[0];
      
      case SchedulingAlgorithm.RR:
        // Use the Round Robin queue to maintain proper order
        for (const processId of roundRobinQueue) {
          const process = readyProcesses.find(p => p.id === processId);
          if (process) {
            return process;
          }
        }
        // Fallback if queue is empty
        return readyProcesses[0];
      
      default:
        return readyProcesses[0];
    }
  }, [processes, algorithm, roundRobinQueue]);

  // Check if current process should be preempted by a higher priority process
  const shouldPreempt = useCallback((): boolean => {
    if (!currentProcess || algorithm !== SchedulingAlgorithm.RR || !roundRobinConfig.isPreemptive) {
      return false;
    }

    // Only check for preemption if ordering by priority
    if (roundRobinConfig.orderBy !== 'priority') {
      return false;
    }

    const readyProcesses = processes.filter(p => p.state === ProcessState.READY);
    
    // Check if there's a ready process with higher priority (lower number = higher priority)
    const higherPriorityProcess = readyProcesses.find(p => p.priority < currentProcess.priority);
    
    return !!higherPriorityProcess;
  }, [currentProcess, algorithm, roundRobinConfig, processes]);

  const tick = useCallback(() => {
    setCurrentTime(prev => prev + 1);
    
    // Move NEW processes to READY state when they arrive
    setProcesses(prev => prev.map(p => 
      p.state === ProcessState.NEW && p.arrivalTime <= currentTime
        ? { ...p, state: ProcessState.READY }
        : p
    ));

    // Update waiting times for processes in READY state
    setProcesses(prev => prev.map(p => 
      p.state === ProcessState.READY
        ? { ...p, waitingTime: p.waitingTime + 1 }
        : p
    ));

    // Process I/O operations for BLOCKED processes
    setProcesses(prev => prev.map(p => {
      if (p.state === ProcessState.BLOCKED) {
        // Handle I/O operations
        if (p.currentIOOperation) {
          const updatedIO = {
            ...p.currentIOOperation,
            remainingTime: p.currentIOOperation.remainingTime - 1
          };

          if (updatedIO.remainingTime <= 0) {
            // I/O operation completed, move to READY state
            return {
              ...p,
              state: ProcessState.READY,
              currentIOOperation: undefined,
              ioOperations: [...p.ioOperations, updatedIO]
            };
          } else {
            // Continue I/O operation
            return {
              ...p,
              currentIOOperation: updatedIO
            };
          }
        }

        // Handle system calls
        if (p.currentSystemCall) {
          const updatedSysCall = {
            ...p.currentSystemCall,
            remainingTime: p.currentSystemCall.remainingTime - 1
          };

          if (updatedSysCall.remainingTime <= 0) {
            // System call completed, move to READY state
            return {
              ...p,
              state: ProcessState.READY,
              currentSystemCall: undefined,
              systemCalls: [...p.systemCalls, updatedSysCall]
            };
          } else {
            // Continue system call
            return {
              ...p,
              currentSystemCall: updatedSysCall
            };
          }
        }
      }
      return p;
    }));

    // Check for preemption by higher priority process (only for preemptive Round Robin with priority ordering)
    if (currentProcess && shouldPreempt()) {
      // Preempt current process for higher priority process
      const readyProcess = { ...currentProcess, state: ProcessState.READY };
      setProcesses(prev => prev.map(p => 
        p.id === currentProcess.id ? readyProcess : p
      ));
      
      // Add preempted process to front of Round Robin queue (it gets another chance soon)
      setRoundRobinQueue(prev => [currentProcess.id, ...prev.filter(id => id !== currentProcess.id)]);
      
      setCurrentProcess(null);
      setQuantumRemaining(timeQuantum);
      return; // Don't continue processing this tick
    }

    // Process execution - CRITICAL: Only one process can be running
    if (currentProcess) {
      const updatedProcess = {
        ...currentProcess,
        remainingTime: currentProcess.remainingTime - 1,
        pcb: {
          ...currentProcess.pcb,
          cpuTime: currentProcess.pcb.cpuTime + 1,
          programCounter: currentProcess.pcb.programCounter + 1
        }
      };

      // Decrement quantum for Round Robin AFTER processing
      let newQuantumRemaining = quantumRemaining;
      if (algorithm === SchedulingAlgorithm.RR) {
        newQuantumRemaining = quantumRemaining - 1;
        setQuantumRemaining(newQuantumRemaining);
      }

      if (updatedProcess.remainingTime <= 0) {
        // Process completed
        const completedProcess = {
          ...updatedProcess,
          state: ProcessState.TERMINATED,
          endTime: currentTime + 1,
          turnaroundTime: (currentTime + 1) - updatedProcess.arrivalTime
        };
        
        setProcesses(prev => prev.map(p => 
          p.id === currentProcess.id ? completedProcess : p
        ));
        
        // Remove from Round Robin queue
        setRoundRobinQueue(prev => prev.filter(id => id !== currentProcess.id));
        
        setCurrentProcess(null);
        setQuantumRemaining(timeQuantum);
      } else {
        // Check for quantum expiration AFTER execution (only for Round Robin)
        if (algorithm === SchedulingAlgorithm.RR && newQuantumRemaining <= 0) {
          // Quantum expired, preempt the process
          callbacks?.onTimerInterrupt?.(currentProcess.id, currentProcess.name);
          
          // Move current process to end of ready queue
          const readyProcess = { ...updatedProcess, state: ProcessState.READY };
          setProcesses(prev => prev.map(p => 
            p.id === currentProcess.id ? readyProcess : p
          ));
          
          // Move process to end of Round Robin queue
          setRoundRobinQueue(prev => {
            const filtered = prev.filter(id => id !== currentProcess.id);
            return [...filtered, currentProcess.id];
          });
          
          setCurrentProcess(null);
          setQuantumRemaining(timeQuantum);
          return; // Don't continue processing this tick
        }

        // Check for random events (reduced probability)
        const needsIO = Math.random() < (IO_PROBABILITY * 0.3);
        const needsSystemCall = Math.random() < (SYSTEM_CALL_PROBABILITY * 0.3);
        
        if (needsIO) {
          // Process needs I/O, move to BLOCKED state
          const ioOperation = createIOOperation(currentTime + 1);
          const blockedProcess = {
            ...updatedProcess,
            state: ProcessState.BLOCKED,
            currentIOOperation: ioOperation
          };
          
          setProcesses(prev => prev.map(p => 
            p.id === currentProcess.id ? blockedProcess : p
          ));
          
          // Remove from Round Robin queue temporarily
          setRoundRobinQueue(prev => prev.filter(id => id !== currentProcess.id));
          
          setCurrentProcess(null);
          setQuantumRemaining(timeQuantum);
          
          // Generate I/O interrupt
          callbacks?.onIOInterrupt?.(currentProcess.id, currentProcess.name, ioOperation.type);
        } else if (needsSystemCall) {
          // Process makes system call, move to BLOCKED state
          const systemCall = createSystemCall(currentTime + 1);
          const blockedProcess = {
            ...updatedProcess,
            state: ProcessState.BLOCKED,
            currentSystemCall: systemCall
          };
          
          setProcesses(prev => prev.map(p => 
            p.id === currentProcess.id ? blockedProcess : p
          ));
          
          // Remove from Round Robin queue temporarily
          setRoundRobinQueue(prev => prev.filter(id => id !== currentProcess.id));
          
          setCurrentProcess(null);
          setQuantumRemaining(timeQuantum);
          
          // Generate system call interrupt
          callbacks?.onSystemCallInterrupt?.(currentProcess.id, currentProcess.name, systemCall.type);
        } else {
          // Continue execution - Update both current process and process list
          setCurrentProcess(updatedProcess);
          setProcesses(prev => prev.map(p => 
            p.id === currentProcess.id ? updatedProcess : p
          ));
        }
      }
    }

    // Schedule next process only if no process is currently running
    if (!currentProcess) {
      const nextProcess = getNextProcess();
      if (nextProcess) {
        setCurrentProcess(nextProcess);
        setProcesses(prev => prev.map(p => 
          p.id === nextProcess.id 
            ? { ...p, state: ProcessState.RUNNING, startTime: p.startTime || (currentTime + 1) }
            : p
        ));
        
        // For Round Robin, remove the selected process from the front of the queue
        if (algorithm === SchedulingAlgorithm.RR) {
          setRoundRobinQueue(prev => prev.filter(id => id !== nextProcess.id));
          setQuantumRemaining(timeQuantum); // Reset quantum for new process
        }
      }
    }
  }, [currentTime, currentProcess, algorithm, timeQuantum, roundRobinConfig, quantumRemaining, shouldPreempt, createIOOperation, createSystemCall, getNextProcess, callbacks, roundRobinQueue]);

  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(tick, 1000);
      return () => clearInterval(interval);
    }
  }, [isRunning, tick]);

  const startScheduler = useCallback(() => {
    setIsRunning(true);
  }, []);

  const stopScheduler = useCallback(() => {
    setIsRunning(false);
  }, []);

  const resetScheduler = useCallback(() => {
    setIsRunning(false);
    setCurrentTime(0);
    setCurrentProcess(null);
    setQuantumRemaining(timeQuantum);
    setProcesses([]);
    setRoundRobinQueue([]);
  }, [timeQuantum]);

  const updateRoundRobinConfig = useCallback((config: Partial<RoundRobinConfig>) => {
    setRoundRobinConfig(prev => ({ ...prev, ...config }));
  }, []);

  return {
    processes,
    currentProcess,
    algorithm,
    timeQuantum,
    isRunning,
    currentTime,
    quantumRemaining,
    roundRobinConfig,
    addProcess,
    setAlgorithm,
    setTimeQuantum,
    updateRoundRobinConfig,
    startScheduler,
    stopScheduler,
    resetScheduler
  };
};