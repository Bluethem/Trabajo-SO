export const MEMORY_SIZE = 65536; // 64KB (direccionamiento de 16 bits)
export const PAGE_SIZE = 4096; // Páginas de 4KB
export const FRAME_SIZE = PAGE_SIZE;
export const DEFAULT_FRAME_COUNT = 16; // Número de marcos por defecto
export const MIN_FRAME_COUNT = 4; // Mínimo número de marcos
export const MAX_FRAME_COUNT = 1000; // Máximo número de marcos (4MB total)
export const TIME_QUANTUM = 4; // Para planificación Round Robin
export const MAX_PRIORITY = 10;
export const MIN_PRIORITY = 1;

// Probabilidades para operaciones aleatorias
export const IO_PROBABILITY = 0.25; // 25% probabilidad de E/S por tick
export const SYSTEM_CALL_PROBABILITY = 0.15; // 15% probabilidad de llamada al sistema por tick
export const MIN_IO_DURATION = 2;
export const MAX_IO_DURATION = 6;
export const MIN_SYSCALL_DURATION = 1;
export const MAX_SYSCALL_DURATION = 3;

export const PROCESS_STATE_COLORS = {
  Nuevo: '#6B7280',
  Listo: '#3B82F6',
  Ejecutando: '#10B981',
  Bloqueado: '#F59E0B',
  Terminado: '#EF4444'
};

export const INTERRUPT_COLORS = {
  Temporizador: '#3B82F6',
  'E/S': '#10B981',
  Teclado: '#F59E0B',
  Ratón: '#EF4444',
  Disco: '#8B5CF6',
  Red: '#EC4899',
  'Fallo de Página': '#F97316',
  'Llamada al Sistema': '#06B6D4'
};

export const IO_TYPE_COLORS = {
  'Lectura de Disco': '#8B5CF6',
  'Escritura de Disco': '#7C3AED',
  'Petición de Red': '#EC4899',
  'Entrada de Teclado': '#F59E0B',
  'Entrada de Ratón': '#EF4444',
  'Impresora': '#10B981',
  'Operación de Archivo': '#06B6D4'
};

export const SYSTEM_CALL_COLORS = {
  'Abrir Archivo': '#3B82F6',
  'Leer Archivo': '#10B981',
  'Escribir Archivo': '#F59E0B',
  'Cerrar Archivo': '#EF4444',
  'Asignar Memoria': '#8B5CF6',
  'Liberar Memoria': '#EC4899',
  'Crear Proceso': '#F97316',
  'Terminar Proceso': '#06B6D4',
  'Enviar Red': '#84CC16',
  'Recibir Red': '#F472B6'
};

export const SAMPLE_PROCESSES = [
  { name: 'Navegador', burstTime: 8, priority: 3, memorySize: 2048 },
  { name: 'Editor de Texto', burstTime: 5, priority: 2, memorySize: 1024 },
  { name: 'Reproductor Multimedia', burstTime: 10, priority: 4, memorySize: 3072 },
  { name: 'Calculadora', burstTime: 3, priority: 1, memorySize: 512 },
  { name: 'Explorador de Archivos', burstTime: 7, priority: 2, memorySize: 1536 },
  { name: 'Terminal', burstTime: 4, priority: 2, memorySize: 1024 },
  { name: 'Visor de Imágenes', burstTime: 6, priority: 3, memorySize: 2048 },
  { name: 'Cliente de Email', burstTime: 9, priority: 4, memorySize: 2560 },
  { name: 'Antivirus', burstTime: 12, priority: 5, memorySize: 4096 },
  { name: 'Juego Simple', burstTime: 15, priority: 6, memorySize: 6144 }
];