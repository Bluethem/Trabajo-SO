import React, { useMemo } from 'react';
import { ProcessScheduler } from './components/ProcessScheduler';
import { MemoryManager } from './components/MemoryManager';
import { InterruptManager } from './components/InterruptManager';
import { SystemStats } from './components/SystemStats';
import { useProcessScheduler } from './hooks/useProcessScheduler';
import { useMemoryManager } from './hooks/useMemoryManager';
import { useInterruptManager } from './hooks/useInterruptManager';
import { ProcessState } from './types';
import { Cpu } from 'lucide-react';

function App() {
  const interruptManager = useInterruptManager();
  
  const scheduler = useProcessScheduler({
    onTimerInterrupt: interruptManager.addTimerInterrupt,
    onIOInterrupt: interruptManager.addIOInterrupt,
    onSystemCallInterrupt: interruptManager.addSystemCallInterrupt
  });
  
  const memoryManager = useMemoryManager();

  // Auto-asignar memoria para nuevos procesos
  React.useEffect(() => {
    scheduler.processes.forEach(process => {
      if (process.state === ProcessState.NEW && !process.memoryAddress) {
        const allocated = memoryManager.allocateMemory(process);
        if (allocated) {
          console.log(`Memoria asignada para ${process.name}`);
        } else {
          console.log(`No se pudo asignar memoria para ${process.name}`);
        }
      }
    });
  }, [scheduler.processes, memoryManager]);

  // Auto-liberar memoria para procesos terminados
  React.useEffect(() => {
    const terminatedProcesses = scheduler.processes.filter(p => p.state === ProcessState.TERMINATED);
    
    terminatedProcesses.forEach(process => {
      // Solo liberar memoria si el proceso la tenía asignada
      const hasMemoryAllocated = memoryManager.memoryBlocks.some(block => 
        block.allocated && block.processId === process.id
      );
      
      if (hasMemoryAllocated) {
        memoryManager.deallocateMemory(process.id);
        console.log(`Memoria liberada para ${process.name} (ID: ${process.id})`);
      }
    });
  }, [scheduler.processes, memoryManager]);

  const systemStats = useMemo(() => {
    const processes = scheduler.processes;
    // CRITICAL: Ensure only one process can be running at a time
    const runningProcesses = scheduler.currentProcess ? 1 : 0;
    const readyProcesses = processes.filter(p => p.state === ProcessState.READY).length;
    const blockedProcesses = processes.filter(p => p.state === ProcessState.BLOCKED).length;
    const terminatedProcesses = processes.filter(p => p.state === ProcessState.TERMINATED).length;
    
    const completedProcesses = processes.filter(p => p.state === ProcessState.TERMINATED);
    const averageWaitTime = completedProcesses.length > 0 
      ? completedProcesses.reduce((sum, p) => sum + p.waitingTime, 0) / completedProcesses.length 
      : 0;
    const averageTurnaroundTime = completedProcesses.length > 0 
      ? completedProcesses.reduce((sum, p) => sum + p.turnaroundTime, 0) / completedProcesses.length 
      : 0;

    const cpuUtilization = scheduler.currentProcess ? 100 : 0;
    const memoryUtilization = memoryManager.getMemoryUtilization();

    return {
      totalProcesses: processes.length,
      runningProcesses,
      readyProcesses,
      blockedProcesses,
      terminatedProcesses,
      memoryUtilization,
      cpuUtilization,
      contextSwitches: interruptManager.contextSwitchCount,
      interruptCount: interruptManager.interrupts.length,
      averageWaitTime,
      averageTurnaroundTime
    };
  }, [scheduler, memoryManager, interruptManager]);

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center space-x-3 mb-8">
          <Cpu className="text-blue-500" size={32} />
          <h1 className="text-3xl font-bold text-white">Simulador de Sistema Operativo</h1>
        </div>

        <SystemStats stats={systemStats} />

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <ProcessScheduler
            processes={scheduler.processes}
            currentProcess={scheduler.currentProcess}
            algorithm={scheduler.algorithm}
            timeQuantum={scheduler.timeQuantum}
            isRunning={scheduler.isRunning}
            currentTime={scheduler.currentTime}
            quantumRemaining={scheduler.quantumRemaining}
            roundRobinConfig={scheduler.roundRobinConfig}
            onAlgorithmChange={scheduler.setAlgorithm}
            onTimeQuantumChange={scheduler.setTimeQuantum}
            onRoundRobinConfigChange={scheduler.updateRoundRobinConfig}
            onStart={scheduler.startScheduler}
            onStop={scheduler.stopScheduler}
            onReset={scheduler.resetScheduler}
            onAddProcess={scheduler.addProcess}
          />

          <MemoryManager
            memoryBlocks={memoryManager.memoryBlocks}
            frameTable={memoryManager.frameTable}
            frameCount={memoryManager.frameCount}
            algorithm={memoryManager.algorithm}
            pageReplacementAlgorithm={memoryManager.pageReplacementAlgorithm}
            pageFrames={memoryManager.pageFrames}
            onAlgorithmChange={memoryManager.setAlgorithm}
            onPageReplacementAlgorithmChange={memoryManager.setPageReplacementAlgorithm}
            onFrameCountChange={memoryManager.updateFrameCount}
            utilization={memoryManager.getMemoryUtilization()}
            fragmentation={memoryManager.getFragmentation()}
            totalMemory={memoryManager.getTotalMemory()}
            isSimulationRunning={scheduler.isRunning}
          />
        </div>

        <InterruptManager
          interrupts={interruptManager.interrupts}
          interruptQueue={interruptManager.interruptQueue}
          currentInterrupt={interruptManager.currentInterrupt}
          contextSwitchCount={interruptManager.contextSwitchCount}
          onClearHandled={interruptManager.clearHandledInterrupts}
        />
      </div>
    </div>
  );
}

export default App;